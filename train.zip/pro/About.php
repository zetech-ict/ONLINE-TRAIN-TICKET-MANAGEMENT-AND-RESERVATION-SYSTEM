<!DOCTYPE html>
<?php
include 'constants.php';
?>

<head>   
</head>
<body>
<section class="main-heading" id="home">

<div class="overlay">

    <div class="container">

        <div class="row">

            <div class="main-heading-content col-md-12 col-sm-12 text-center">

                <h1 class="main-heading-title">Hekima Railway Co. Contact List</h1>

                <p class="main-heading-text">The Hekima Railway Corporation is over 100 years old  and streached from Mombasa to kisumu
                
                    <br />The Construction of the Kenya railway began 1890s and was completed on 1901 
                    .network is approximately 3,500 km long and is
                   .
                </p>

                <div class="btn-bar">

                    <a href="system/" class="btn btn-custom theme_background_color">Get Started</a>

                    <a href="system/admin" class="btn btn-custom-outline">Admin</a>

                </div>

            </div>

        </div>

    </div>

</div>


</section>


<!-- [/MAIN-HEADING]

============================================================================================================================-->



<!-- [ABOUT US]

============================================================================================================================-->

<section class="aboutus bule-background white" id="two">

<div class="container">

    <div class="row">

        <div class="col-md-12 text-center black">

            <h3 class="title">ABOUT <span class="themecolor">US</span></h3>

            <p class="a-slog">Developed By <?php echo $developer_name; ?> 
                and Supervised By <?php echo $supervisor_name; ?></p>
        </div>

    </div>

    <div class="gap">


    </div>


    <div class="row about-box">

        <div class="col-sm-4 text-center">

            <div class="margin-bottom">

                <i class="fa fa-train"></i>

                <h4>Get Train Tickets from the comfort of your home</h4>

                <p class="black">Book train tickets from anywhere using the robust ticketing platform
                    exclusively built to provide the passengers with pleasant ticketing experience. </p>

            </div> <!-- / margin -->

        </div> <!-- /col -->

        <div class="col-sm-4 about-line text-center">

            <div class="margin-bottom">

                <i class="fa fa-square"></i>

                <h4>Train & Ticketing related information at your fingertips</h4>

                <p class="black">Checkout available seats, route information, fare information on real time
                    basis with Esheba Platform.</p>

            </div> <!-- / margin -->

        </div><!-- /col -->

        <div class="col-sm-4 text-center">

            <div class="margin-bottom">

                <i class=>Kshs</i>

                <h4>Pay Securely</h4>

                <p class="black">Online payment. (NO REFUND!)</p>

            </div> <!-- / margin -->

        </div><!-- /col -->

    </div> <!-- /row -->





</div>
</section>
</html>