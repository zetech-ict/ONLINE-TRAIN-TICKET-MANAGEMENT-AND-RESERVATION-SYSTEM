<?php
$title = 'Online Train Ticket Reservation And Management System';
// online ticketing System For Railway
$supervisor_name = "Fredrick Ochieng";
$developer_name = "Nancy Ketere";
